package com.jempton.careerled;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Spinner;

/**
 * Created by BALE on 27/09/2015.
 */
public class ActivityForumChat extends ActionBarActivity {

    Button saveButton;
    ProgressDialog progress;
    ImageButton backButton;
    String[] levels = {"Junior Secondary", "Senior Secondary", "University/College"};
    String[] areas = {"Arts", "Social Science", "Science", "Technology"};
    String[] fields = {"Pure Sciences", "Health Science", "Engineering"};
    String[] courses = {"Computer Science", "Micro Biology", "Petroleum Engineering"};
    ArrayAdapter<String> a1, a2, a3, a4;
    Spinner s1, s2, s3, s4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forum_chat);

        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);//This hides the automatic keyboard when activity starts
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();
    }

}