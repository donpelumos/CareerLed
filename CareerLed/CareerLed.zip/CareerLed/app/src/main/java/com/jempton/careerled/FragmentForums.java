package com.jempton.careerled;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

/**
 * Created by BALE on 27/09/2015.
 */
public class FragmentForums extends Fragment {
    MenuList [] menuListData;
    ListView settingsList;

    public FragmentForums(){

    }

    @Override
    public View onCreateView(LayoutInflater inflater, final ViewGroup container, Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.fragment_forums, container, false);
        settingsList = (ListView)rootView.findViewById(R.id.forums_list);
        menuListData = new MenuList[]{
                new MenuList("Forum 1",R.drawable.icon ), new MenuList("Forum 2",R.drawable.icon ),
                new MenuList("Forum 3",R.drawable.icon ),
                new MenuList("Forum 4",R.drawable.icon ), new MenuList("Forum 5",R.drawable.icon),
                new MenuList("Forum 6",R.drawable.icon ), new MenuList("Forum 7",R.drawable.icon),
                new MenuList("Forum 8",R.drawable.icon), new MenuList("Forum 9",R.drawable.icon),
                new MenuList("Forum 10",R.drawable.icon), new MenuList("Forum 11",R.drawable.icon),
                new MenuList("Forum 12",R.drawable.icon)};

        final SettingsAdapter adp = new SettingsAdapter(rootView.getContext(),R.layout.row_forums, menuListData );
        settingsList.setAdapter(adp);

        settingsList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(rootView.getContext(), ActivityForumChat.class);
                startActivity(intent);

            }
        });
        return rootView;
    }
}
