package com.jempton.careerled;

/**
 * Created by BALE on 28/09/2015.
 */
public class NetworkList {
    String personName;
    int personImage;
    public NetworkList(String personName, int personImage){
        this.personImage = personImage;
        this.personName = personName;
    }
}
