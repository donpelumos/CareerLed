package com.jempton.careerled;

/**
 * Created by BALE on 28/08/2015.
 */
public class MenuList {
    String menuName;
    int menuImage;
    public MenuList(String menuName, int menuImage){
        this.menuImage = menuImage;
        this.menuName = menuName;
    }
}
