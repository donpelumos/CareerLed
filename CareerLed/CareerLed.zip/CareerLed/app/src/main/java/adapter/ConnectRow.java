package adapter;

/**
 * Created by BALE on 04/09/2015.
 */
public class ConnectRow {
    String connectName;
    int connectImage;
    public ConnectRow(String menuName, int menuImage){
        this.connectImage = menuImage;
        this.connectName = menuName;
    }
}
